-- Macademia — Decision Trees: per-user Mac pilot installer.
-- Readable source. No administrator access, Node.js or Terminal window required.
-- Installs only manifest ID 396b9627-3919-4f47-b82c-a46a69888cca.
set appTitle to "Macademia — Decision Trees"
display dialog "Install Macademia — Decision Trees for this Mac account?\n\nSave your work and quit Excel first. This adds a hosted Excel add-in and backs up older manifests with the same add-in ID. An internet connection is required to open the editor." buttons {"Cancel", "Install"} default button "Install" cancel button "Cancel" with title appTitle
try
  do shell script "/usr/bin/pgrep -x 'Microsoft Excel' >/dev/null 2>&1"
  display dialog "Excel is still running. Save your work and quit Excel, then run this installer again." buttons {"OK"} default button "OK" with title appTitle
  return
on error number 1
  -- pgrep reports 1 when Excel is not running.
end try
set userHome to POSIX path of (path to home folder)
set targetFolder to userHome & "Library/Containers/com.microsoft.Excel/Data/Documents/wef/"
set targetFile to targetFolder & "Macademia.DecisionTrees.xml"
set backupFolder to userHome & "Library/Application Support/Macademia/Manifest Backups/" & (do shell script "/bin/date +%Y%m%d-%H%M%S") & "/"
set manifestText to "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<OfficeApp xmlns=\"http://schemas.microsoft.com/office/appforoffice/1.1\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:bt=\"http://schemas.microsoft.com/office/officeappbasictypes/1.0\" xsi:type=\"TaskPaneApp\">\n  <Id>396b9627-3919-4f47-b82c-a46a69888cca</Id>\n  <Version>1.0.0.1</Version>\n  <ProviderName>Macademia</ProviderName>\n  <DefaultLocale>en-US</DefaultLocale>\n  <DisplayName DefaultValue=\"Macademia — Decision Trees\"/>\n  <Description DefaultValue=\"Build and analyze decision trees directly in Excel for Mac.\"/>\n  <IconUrl DefaultValue=\"https://macademia-create.github.io/Decision-Tree/assets/icon-32.png\"/>\n  <HighResolutionIconUrl DefaultValue=\"https://macademia-create.github.io/Decision-Tree/assets/icon-64.png\"/>\n  <SupportUrl DefaultValue=\"https://macademia-create.github.io/Decision-Tree/help.html\"/>\n  <AppDomains><AppDomain>https://macademia-create.github.io/Decision-Tree</AppDomain></AppDomains>\n  <Hosts><Host Name=\"Workbook\"/></Hosts>\n  <Requirements><Sets DefaultMinVersion=\"1.9\"><Set Name=\"ExcelApi\" MinVersion=\"1.9\"/></Sets></Requirements>\n  <DefaultSettings><SourceLocation DefaultValue=\"https://macademia-create.github.io/Decision-Tree/taskpane.html\"/></DefaultSettings>\n  <Permissions>ReadWriteDocument</Permissions>\n  <VersionOverrides xmlns=\"http://schemas.microsoft.com/office/taskpaneappversionoverrides\" xsi:type=\"VersionOverridesV1_0\">\n    <Requirements><bt:Sets DefaultMinVersion=\"1.1\"><bt:Set Name=\"ExcelApi\" MinVersion=\"1.9\"/></bt:Sets></Requirements>\n    <Hosts><Host xsi:type=\"Workbook\"><DesktopFormFactor>\n      <FunctionFile resid=\"Commands.Url\"/>\n      <ExtensionPoint xsi:type=\"PrimaryCommandSurface\"><OfficeTab id=\"TabHome\"><Group id=\"Macademia.DecisionTrees.Group\">\n        <Label resid=\"Suite.Label\"/>\n        <Icon><bt:Image size=\"16\" resid=\"Icon.16\"/><bt:Image size=\"32\" resid=\"Icon.32\"/><bt:Image size=\"80\" resid=\"Icon.80\"/></Icon>\n        <Control xsi:type=\"Button\" id=\"Macademia.DecisionTrees.Open\">\n          <Label resid=\"Button.Label\"/>\n          <Supertip><Title resid=\"Button.Label\"/><Description resid=\"Button.Help\"/></Supertip>\n          <Icon><bt:Image size=\"16\" resid=\"Icon.16\"/><bt:Image size=\"32\" resid=\"Icon.32\"/><bt:Image size=\"80\" resid=\"Icon.80\"/></Icon>\n          <Action xsi:type=\"ShowTaskpane\"><TaskpaneId>Macademia.DecisionTrees</TaskpaneId><SourceLocation resid=\"Taskpane.Url\"/></Action>\n        </Control>\n      </Group></OfficeTab></ExtensionPoint>\n    </DesktopFormFactor></Host></Hosts>\n    <Resources>\n      <bt:Images><bt:Image id=\"Icon.16\" DefaultValue=\"https://macademia-create.github.io/Decision-Tree/assets/icon-16.png\"/><bt:Image id=\"Icon.32\" DefaultValue=\"https://macademia-create.github.io/Decision-Tree/assets/icon-32.png\"/><bt:Image id=\"Icon.80\" DefaultValue=\"https://macademia-create.github.io/Decision-Tree/assets/icon-80.png\"/></bt:Images>\n      <bt:Urls><bt:Url id=\"Commands.Url\" DefaultValue=\"https://macademia-create.github.io/Decision-Tree/commands.html\"/><bt:Url id=\"Taskpane.Url\" DefaultValue=\"https://macademia-create.github.io/Decision-Tree/taskpane.html\"/></bt:Urls>\n      <bt:ShortStrings><bt:String id=\"Suite.Label\" DefaultValue=\"Macademia\"/><bt:String id=\"Button.Label\" DefaultValue=\"Decision Trees\"/></bt:ShortStrings>\n      <bt:LongStrings><bt:String id=\"Button.Help\" DefaultValue=\"Open Macademia — Decision Trees. Build, edit, analyze and export decision trees in this workbook.\"/></bt:LongStrings>\n    </Resources>\n  </VersionOverrides>\n</OfficeApp>"
set fileHandle to missing value
try
  do shell script "/bin/mkdir -p " & quoted form of targetFolder
  set backupCommand to "for f in " & quoted form of targetFolder & "*.xml; do if [ -f \"$f\" ] && /usr/bin/grep -qF '396b9627-3919-4f47-b82c-a46a69888cca' \"$f\"; then /bin/mkdir -p " & quoted form of backupFolder & "; /bin/mv \"$f\" " & quoted form of backupFolder & "; fi; done"
  do shell script backupCommand
  set fileHandle to open for access (POSIX file targetFile) with write permission
  set eof fileHandle to 0
  write manifestText to fileHandle as «class utf8»
  close access fileHandle
  set fileHandle to missing value
  display dialog "Installation complete.\n\n1. Open Excel.\n2. Choose Home → Add-ins → Macademia — Decision Trees.\n3. Use Home → Macademia → Decision Trees (the logo button).\n\nNo Terminal or Node.js is needed. This pilot requires internet and permission to use custom add-ins in Excel." buttons {"Done"} default button "Done" with title appTitle
on error errorText number errorNumber
  try
    if fileHandle is not missing value then close access fileHandle
  end try
  display dialog "Installation could not finish: " & errorText & "\n\nUse the manual Finder instructions in README.html. Any older manifests that were moved are in: " & backupFolder buttons {"OK"} default button "OK" with title appTitle
end try
